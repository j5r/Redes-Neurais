# using Python3.8
import numpy as np

__all__ = ["Layer", "OutputLayer", "Sequencer", "MLP"]


class Color:
    # colors
    red = "\033[91m"
    green = "\033[92m"
    yellow = "\033[93m"
    blue = "\033[94m"
    magenta = "\033[95m"
    cyan = "\033[96m"
    # styles
    bold = "\033[1m"
    dark = "\033[2m"
    emph = "\033[3m"
    under = "\033[4m"
    twink = "\033[5m"
    invert = "\033[7m"
    # clear
    clear = "\033[m"


class Layer(object):
    def __init__(self,
                 n: int,
                 act_fun="logistic"
                 ):
        """
        |in >> n:int, act_fun:str :: "logistic"
        |out>> None
        """
        self._n = n
        self._act_name = act_fun

        if act_fun.lower() == "logistic":
            self._fun = Layer.__lg
            self._dfun = Layer.__dlg
        elif act_fun.lower() == "relu":
            self._fun = Layer.__relu
            self._dfun = Layer.__drelu
        elif act_fun.lower() == "tanh":
            self._fun = Layer.__tanh
            self._dfun = Layer.__dtanh
        else:
            raise ValueError(
                Color.red + "\n<Layer.__init__> says: " + Color.bold +
                "Activation function not recognized." +
                "\nPlease, select one among 'logistic', 'relu' or 'tanh'." +
                Color.clear
            )

        self._weigths = None
        self._weigths_dimension = None
        self._biases = None
        self._biases_dimension = None
        self._delta = None
        self._Delta_weigths = None
        self._Delta_biases = None
        self._input = None  # input for this layer
        self._out_act = None  # activation of self._out
        self._out = None  # sum of the products of weigths and entries plus biases

    def _init_weigths(self):
        self._weigths = np.random.normal(0, 1, size=self._weigths_dimension)
        self._biases_dimension = (self._weigths_dimension[0], 1)
        self._biases = np.random.normal(
            0, 1, size=self._biases_dimension
        )
        self._Delta_weigths = np.zeros(self._weigths_dimension)
        self._Delta_biases = np.zeros(self._biases_dimension)

    def __repr__(self):
        s = "Layer:\t" + Color.dark
        s += f"{self._n} neurons with activation function <{self._act_name}>"
        s += "\n\tWeigths shape is "
        s += Color.bold + str(self._weigths_dimension) + \
            Color.clear + Color.dark
        s += " and biases shape is " + Color.bold + \
            str(self._biases_dimension) + "."
        s += Color.clear
        return s

    def __lg(x: np.array) -> np.array:
        """
        |in >> x: np.array: shape=(n,1)
        |out>> np.array: shape=(n,1)
        """
        return (
            1/(1 + np.exp(-x * (x < 20) * (x > -20)))
            + 0.5*(x >= 20) - 0.5*(x <= -20)
        )

    def __dlg(x: np.array) -> np.array:
        """
        |in >> x: np.array: shape=(n,1)
        |out>> np.array: shape=(n,1)
        """
        return Layer.__lg(x) * (1-Layer.__lg(x))

    def __relu(x: np.array) -> np.array:
        """
        |in >> x: np.array: shape=(n,1)
        |out>> np.array: shape=(n,1)
        """
        return x * (x > 0)

    def __drelu(x: np.array) -> np.array:
        """
        |in >> x: np.array: shape=(n,1)
        |out>> np.array: shape=(n,1)
        """
        return 1 * (x > 0)

    def __tanh(x: np.array) -> np.array:
        """
        |in >> x: np.array: shape=(n,1)
        |out>> np.array: shape=(n,1)
        """
        return (
            (np.exp(2 * x * (x < 20) * (x > -20)) - 1) /
            (np.exp(2 * x * (x < 20) * (x > -20)) + 1) +
            1 * (x > 20) - 1 * (x < -20)
        )

    def __dtanh(x: np.array) -> np.array:
        """
        |in >> x: np.array: shape=(n,1)
        |out>> np.array: shape=(n,1)
        """
        return 1 - Layer.__tanh(x)**2


class Sequencer(object):
    def __init__(self,
                 layers: [Layer]
                 ) -> None:
        """
        |in >> [Layer]
        |out>> None
        """
        self._layers = layers

    def __repr__(self) -> None:
        s = "Sequencer(["
        for i, l in enumerate(self._layers):
            s += Color.dark + f"\n  ({i+1}) " + l.__repr__()
        s += "\n\t])"
        return s

    def _print(self):
        s = ""
        for i, l in enumerate(self._layers):
            s += Color.cyan + f"Layer {i+1}" + "-"*33 + "\n"
            s += "Weigths:\n"
            s += Color.dark+l._weigths.__repr__() + "\n" + Color.clear
            s += Color.cyan + "Biases:\n"
            s += Color.dark+l._biases.__repr__() + "\n" + Color.clear
        s += Color.cyan + "-"*40 + Color.clear
        print(s)


class MLP(object):
    def __init__(self,
                 seq: Sequencer
                 ):
        """
        |in >> Sequencer
        |out>> None
        """
        self._seq = seq
        self._isconfigured = False
        self._istrained = False

    def configure(self,
                  maxit=1000,
                  eta=0.5,
                  momentum=0.0,
                  tolerance=0.0,  # NOT IMPLEMENTED
                  batch_size=1,
                  seed=10,
                  stochastic=1.0,
                  ) -> None:
        """
        |in >> maxit:int::1000: maximum number of iterations
               eta:float::0.5: learning rate between 0 and 1
               momentum:float::0.0: size of the momentum term
               tolerance:float::0.0: if the error becomes smaller than tolerance,
                    the algorithm stops
               batch_size:int::1: the size of the batch (must be less than the
                    number of the patterns of trainment)
               seed:int::10: the random seed for initializing everything;
                    if you want not use seed, set it as None
               stochastic:float::1.0: the probability to randomize the weigths
                    and biases for updating
        |out>> None
        """
        self._max_iterations = maxit
        self._eta = eta
        self._momentum = momentum
        self._tolerance = tolerance
        self._stochastic = stochastic
        self._batch_size = batch_size

        if seed is not None:
            np.random.seed(seed)
        self._isconfigured = True

    def fit(self,
            X_train: np.array,
            Y_train: np.array
            ) -> None:
        """
        Train the network with m patterns
        |in >> X_train: np.array: shape=(m,p), Y_train: np.array: shape=(m,q)
        |out >> None
        """
        if not self._isconfigured:
            raise Exception(
                Color.red + "\n<MLP.fit> says: " + Color.bold +
                "Please, use the MLP.configure() method first." +
                Color.clear
            )
        if Y_train.shape[1] != self._seq._layers[-1]._n:
            raise IndexError(
                Color.red + "\n<MLP.fit> says: " + Color.bold +
                f"The OutputLayer has {self._seq._layers[-1]._n} neurons and " +
                f"your outputs Y_train have length {Y_train.shape[1]}," +
                "\n that is not compatible" + Color.clear
            )
        # BEGIN: INITIALIZING THE BIASES AND WEIGTHS FOR ALL LAYERS
        for i in range(1, len(self._seq._layers)):
            self._seq._layers[i]._weigths_dimension = (
                self._seq._layers[i]._n,
                self._seq._layers[i-1]._n,
            )
        self._seq._layers[0]._weigths_dimension = (
            self._seq._layers[0]._n,
            X_train.shape[1],
        )
        _ = [
            self._seq._layers[i]._init_weigths()
            for i in range(len(self._seq._layers))
        ]
        # END: INITIALIZING THE BIASES AND WEIGTHS FOR ALL LAYERS

        row_indices = list(range(X_train.shape[0]))

        # BEGIN: INITIALIZING THE sum_Delta_weights, sum_Delta_biases
        error, squared_error, mean_squared_error = self._forwardpropagate(
            X_train[0, :], Y_train[0, :]
        )
        sum_Delta_weigths, sum_Delta_biases = self.__backpropagate(error)
        momentum_weigths = 0*sum_Delta_weigths
        momentum_biases = 0*sum_Delta_biases
        # END: INITIALIZING THE sum_Delta_weights, sum_Delta_biases

        for epoch in range(self._max_iterations):
            # shuffling the indices
            np.random.shuffle(row_indices)

            # splitting X_train and Y_train into batches
            X_batchs = np.vsplit(
                X_train[row_indices, :],
                range(0, X_train.shape[0], self._batch_size),
            )
            Y_batchs = np.vsplit(
                Y_train[row_indices, :],
                range(0, X_train.shape[0], self._batch_size),
            )

            # passing through all batches
            for Xs, Ys in zip(X_batchs, Y_batchs):
                sum_Delta_weights = 0*sum_Delta_weigths
                sum_Delta_biases = 0*sum_Delta_biases
                # passing through all patterns in the batch [Xs,Ys]
                for X, Y in zip(Xs, Ys):
                    error, _, mean_squared_error = (
                        self._forwardpropagate(X, Y)
                    )
                    Delta_weigths, Delta_biases = self.__backpropagate(error)

                    sum_Delta_weigths += Delta_weigths
                    sum_Delta_biases += Delta_biases

                # scaling the descent direction by the learning rate eta
                sum_Delta_weigths *= self._eta
                sum_Delta_biases *= self._eta

                # if needed, we add momentum
                if self._momentum > 0:
                    sum_Delta_weigths += self._momentum * momentum_weigths
                    sum_Delta_biases += self._momentum * momentum_biases

                # if needed, we perform the stochastic gradient
                if self._stochastic < 1:
                    sum_Delta_weigths = np.asarray([
                        sum_Delta_weigths[i]*np.where(
                            np.random.rand(*sum_Delta_weigths[i].shape)
                            < self._stochastic, 1, 0
                        )
                        for i in range(len(sum_Delta_weigths))
                    ])
                    sum_Delta_biases = np.asarray([
                        sum_Delta_biases[i]*np.where(
                            np.random.rand(*sum_Delta_biases[i].shape)
                            < self._stochastic, 1, 0
                        )
                        for i in range(len(sum_Delta_biases))
                    ])

                # updating the weigths and biases
                for i in range(len(self._seq._layers)):
                    self._seq._layers[i]._weigths = self._seq._layers[i]._weigths + \
                        sum_Delta_weigths[i]
                    self._seq._layers[i]._biases = self._seq._layers[i]._biases + \
                        sum_Delta_biases[i]
            print("Training [{:>3d}%]".format(
                int(100*(epoch+1)/self._max_iterations)), end="\r")
        print("\nTrainment Done.")
        self._istrained = True

    def _forwardpropagate(self, X: np.array, Y: np.array) -> (np.array, float, float):
        """
        |in >> X:np.array: a pattern
               Y:np.array: the desired output of this pattern
        |out>> error:np.array: the error vector
               squared_error:float: half of the sum of squared errors
               mean_squared_error:float: the mean of the squared errors
        """
        X = X.reshape(-1, 1)
        Y = Y.reshape(-1, 1)

        self._seq._layers[0]._input = X

        for i in range(len(self._seq._layers)):
            # multiplying weigths and entries and summing biases
            self._seq._layers[i]._out = (
                self._seq._layers[i]._weigths @ self._seq._layers[i]._input
            )

            # activating the previous values
            self._seq._layers[i]._out_act = self._seq._layers[i]._fun(
                self._seq._layers[i]._out
            )

            if i < len(self._seq._layers) - 1:
                self._seq._layers[i+1]._input = self._seq._layers[i]._out_act

        error = Y - self._seq._layers[-1]._out_act
        squared_error = 0.5*error.T @ error
        mean_squared_error = 2*squared_error/Y.shape[1]
        return error, squared_error.item(), mean_squared_error.item()

    def __backpropagate(self, error: np.array) -> (np.array, np.array):
        """
        |in >> error:np.array: the error vector obtained when
                    a pattern X has been forwardpropagated
        |out>> Delta_weigths:np.array: (dtype=object) the set of all
                    Delta_weights for all layers
               Delta_biases:np.array: (dtype=object) the set of all
                    Delta_biases for all layers
        """
        # computing the delta of the last hidden layer
        self._seq._layers[-1]._delta = error * self._seq._layers[-1]._dfun(
            self._seq._layers[-1]._out
        )
        self._seq._layers[-1]._Delta_weigths = (
            self._seq._layers[-1]._delta
            @
            self._seq._layers[-1]._out_act.T
        )
        self._seq._layers[-1]._Delta_biases = self._seq._layers[-1]._delta

        # doing the same thing for the other layers
        for i in reversed(range(len(self._seq._layers)-1)):
            self._seq._layers[i]._delta = (
                self._seq._layers[i]._dfun(
                    self._seq._layers[i]._out
                )
                *
                (
                    self._seq._layers[i+1]._weigths.T
                    @
                    self._seq._layers[i+1]._delta
                )
            )
        for i in reversed(range(len(self._seq._layers))):
            self._seq._layers[i]._Delta_weigths = (
                self._seq._layers[i]._delta
                @
                self._seq._layers[i]._input.T
            )
            self._seq._layers[i]._Delta_biases = self._seq._layers[i]._delta

        Delta_weigths = np.asarray([
            self._seq._layers[i]._Delta_weigths
            for i in range(len(self._seq._layers))
        ], dtype=object)

        Delta_biases = np.asarray([
            self._seq._layers[i]._Delta_biases
            for i in range(len(self._seq._layers))
        ], dtype=object)

        return Delta_weigths, Delta_biases

    def score(self,
              X_test: np.array,
              Y_test: np.array,
              problem="classification",
              tolerance=0.01,
              ) -> (float, int):
        """
        Test the network with m patterns
        |in >> X_test: np.array: shape=(m,p), Y_test: np.array: shape=(m,q)
               problem:str::'classification': an option between 'classification'
                    and 'regression'
               tolerance:float::0.01: for the regression problem, when the norm
                    of the error is less than the tolerance, it is accounted as
                    a hit.
        |out >> {"accuracy": accuracy, "hits": hits}
                    accuracy:float: the accuracy in percentage
                    hits:int: the number of hits
        """
        if problem.lower() not in ["classification", "regression"]:
            raise ValueError(
                Color.red + "\n<MLP.configure> says: " + Color.bold +
                "'problem' not recognized. \nPlease select one between " +
                "'classification' or 'regression'." + Color.clear
            )
        if not self._istrained:
            raise Exception(
                Color.red + "\n<MLP.score> says: " + Color.bold +
                "You must to train the network first." +
                "\nPlease, use the MLP.fit() method." + Color.clear
            )
        hits, misses = 0, 0
        if problem.lower() == "classification":

            for i in range(X_test.shape[0]):

                X = X_test[i, :]
                Y = Y_test[i, :]

                self._forwardpropagate(X, Y)
                correct = np.argmax(Y) == np.argmax(
                    self._seq._layers[-1]._out_act
                )
                if correct:
                    hits += 1
                else:
                    misses += 1
        else:
            for i in range(X_test.shape[0]):

                X = X_test[i, :]
                Y = Y_test[i, :]

                self._forwardpropagate(X, Y)
                correct = (
                    np.linalg.norm(Y - self._seq._layers[-1]._out_act)
                    < tolerance
                )
                if correct:
                    hits += 1
                else:
                    misses += 1
        accuracy = (hits/(hits+misses))
        return {"accuracy": accuracy, "hits": hits}

    def __repr__(self):
        return (
            "MLP(\n\t" + Color.dark
            + self._seq.__repr__().replace("\n", "\n\t")[:-2]
            + Color.dark + "])"
            + Color.clear + "\n)"
        )

    def print_solution(self):
        self._seq._print()


OutputLayer = Layer
