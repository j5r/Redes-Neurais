import numpy as np
from sklearn.cluster import KMeans


class RBF:
    def __init__(self, X: np.array, Y: np.array, n_clusters=10,filename="RBF"):
        """
        X and Y are row-wise data: X is the pattern set and Y the output set
        """
        self.nptos, self.xdim = X.shape
        self.ydim = Y.shape[1]
        self.n_clusters = n_clusters
        self.centroids = None
        self.radiuses = None
        self.filename = filename

        # loading self.centroids and self.radiuses
        self.__load()
        if self.centroids is None:
            # Starting KMEANS
            print("\033[93mStarting K-Means...\033[m", end="\t\t")
            km = KMeans(n_clusters=n_clusters, random_state=0)
            km.fit(X)
            print("Done.")

            # all tada and centroids are row-wise
            centroids = km.cluster_centers_

            # computing radiuses
            radiuses = []
            for i in range(self.n_clusters):
                radius = 1
                radiuses.append(radius)

            self.centroids = centroids
            self.radiuses = radiuses
            self.__save()		

    def __rbf1x_for_1c(x: np.array, c: np.array, r):
        """
        changing one x from <data basis> to a <rbf basis> with respect
        to an unique centroid
        """
        x = x.reshape(-1, 1)
        c = c.reshape(-1, 1)
        return np.exp(-np.linalg.norm(x-c)**2/r**2)

    def __rbf1x_for_nc(self, x: np.array, centroids: np.array):
        """
        changing one x from <data basis> to a <rbf basis> with respect
        to all n centroids
        """
        return np.asarray([
            RBF.__rbf1x_for_1c(x, self.centroids[i,:], self.radiuses[i])
            for i in range(self.n_clusters)
        ])

    def change_basis(self, X: np.array):
        """
        change all row-wise data from <data basis> to a <rbf basis>
        with respect to all centroids
        """
        return np.asarray([
            self.__rbf1x_for_nc(X[i,:], self.centroids)
            for i in range(X.shape[0])
        ])

    def __save(self):
        print(f"\033[93mSaving <{self.filename}rbf_centroids_and_radiuses.npz>...", end="\t")
        np.savez(self.filename+"rbf_centroids_and_radiuses.npz",
                 self.centroids, self.radiuses)
        print("\033[mDone.")

    def __load(self):
        print(
            f"\033[93mLooking for <{self.filename}rbf_centroids_and_radiuses.npz>. . .\033[m",
            end="\t")
        try:
            dct = np.load(self.filename+"rbf_centroids_and_radiuses.npz")
            self.centroids, self.radiuses = list(dct.values())
            print("Done.")
        except:
            print("\033[4mNot Found.\033[m")
