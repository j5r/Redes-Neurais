# using Python3.8
from rrbf import RBF
import numpy as np
import matplotlib.pyplot as plt
from mlp import (
	Layer, 
	OutputLayer, 
	Sequencer,
	MLP,
)
from load import X,Y



XX = np.asarray(X)
YY = np.asarray(Y)

DICT = {
"maxit":1000,
"batch_size":20,
"stochastic":0.7,
"momentum":0.01,
"eta":0.1,
}
try:
	########################################################## MLP
	mlp = MLP(
		Sequencer([
			Layer(2),
			OutputLayer(3),
		])
	)

	mlp.configure(**DICT)

	mlp.fit(XX, YY)

	print(mlp.score(XX, YY, problem="classification"))
	print(mlp)




	points_for_plotting = []
	classe = []
	for X, Y in zip(XX,YY):
		X = X.reshape(1,-1)
		Y = Y.reshape(1,-1)
		
		mlp._forwardpropagate(X, Y)
		
		x,y = mlp._seq._layers[-2]._out_act.tolist()
		
		
		points_for_plotting.append(
			[x,y]
		)
		classe.append(np.argmax(mlp._seq._layers[-1]._out_act))

	points_for_plotting = np.asarray(points_for_plotting)

	clsa = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==0])
	clsb = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==1])
	clsc = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==2])




	print(clsa.shape)
	print(clsb.shape)
	print(clsc.shape)

	plt.plot(clsa[:,0],clsa[:,1],"*")
	plt.plot(clsb[:,0],clsb[:,1],"*")
	plt.plot(clsc[:,0],clsc[:,1],"*")
	
	plt.title("MLP sigmoid")
	plt.show()
	
except Exception as e:
	print(e)
	
	
	########################################################## RBF
try:	
	rbf = RBF(XX,YY,2,"logistic")

	rbfX = rbf.change_basis(XX)

	rbfnetwork = MLP(
		Sequencer([
			Layer(2),
			OutputLayer(3),
		])
	)

	rbfnetwork.configure(**DICT)

	# training with the rbf basis
	rbfnetwork.fit(rbfX, YY)

	print(rbfnetwork.score(rbfX, YY, problem="classification"))


	points_for_plotting = []
	classe = []
	for X, Y in zip(rbfX,YY):
		X = X.reshape(1,-1)
		Y = Y.reshape(1,-1)
		rbfnetwork._forwardpropagate(X, Y)
		
		x,y = rbfnetwork._seq._layers[-2]._out_act.tolist()
		
		
		points_for_plotting.append(
			[x,y]
		)
		classe.append(np.argmax(rbfnetwork._seq._layers[-1]._out_act))

	points_for_plotting = np.asarray(points_for_plotting)

	clsa = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==0])
	clsb = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==1])
	clsc = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==2])




	print(clsa.shape)
	print(clsb.shape)
	print(clsc.shape)


	plt.plot(clsa[:,0],clsa[:,1],"*")
	plt.plot(clsb[:,0],clsb[:,1],"*")
	plt.plot(clsc[:,0],clsc[:,1],"*")
	plt.title("RBF sigmoid")
	plt.show()
except Exception as e:
	print(e)







########################################################
########################################################
########################################################
########################################################
########################################################
########################################################
########################################################
########################################################
########################################################
########################################################
########################################################
########################################################

########################################################## MLP
try:
	mlp = MLP(
		Sequencer([
			Layer(2,act_fun="tanh"),
			OutputLayer(3),
		])
	)

	mlp.configure(**DICT)

	mlp.fit(XX, YY)

	print(mlp.score(XX, YY, problem="classification"))
	print(mlp)




	points_for_plotting = []
	classe = []
	for X, Y in zip(XX,YY):
		X = X.reshape(1,-1)
		Y = Y.reshape(1,-1)
		mlp._forwardpropagate(X, Y)
		
		x,y = mlp._seq._layers[-2]._out_act.tolist()
		
		
		points_for_plotting.append(
			[x,y]
		)
		classe.append(np.argmax(mlp._seq._layers[-1]._out_act))

	points_for_plotting = np.asarray(points_for_plotting)

	clsa = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==0])
	clsb = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==1])
	clsc = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==2])




	print(clsa.shape)
	print(clsb.shape)
	print(clsc.shape)

	plt.plot(clsa[:,0],clsa[:,1],"*")
	plt.plot(clsb[:,0],clsb[:,1],"*")
	plt.plot(clsc[:,0],clsc[:,1],"*")
	plt.title("MLP tanh")
	plt.show()
except Exception as e:
	print(e)
	
	########################################################## RBF
try:
	rbf = RBF(XX,YY,2,"tanh")

	rbfX = rbf.change_basis(XX)

	rbfnetwork = MLP(
		Sequencer([
			Layer(2,act_fun="tanh"),
			OutputLayer(3),
		])
	)

	rbfnetwork.configure(**DICT)

	# training with the rbf basis
	rbfnetwork.fit(rbfX, YY)

	print(rbfnetwork.score(rbfX, YY, problem="classification"))


	points_for_plotting = []
	classe = []
	for X, Y in zip(rbfX,YY):
		X = X.reshape(1,-1)
		Y = Y.reshape(1,-1)	
		rbfnetwork._forwardpropagate(X, Y)
		
		x,y = rbfnetwork._seq._layers[-2]._out_act.tolist()
		
		
		points_for_plotting.append(
			[x,y]
		)
		classe.append(np.argmax(rbfnetwork._seq._layers[-1]._out_act))

	points_for_plotting = np.asarray(points_for_plotting)

	clsa = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==0])
	clsb = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==1])
	clsc = np.asarray([points_for_plotting[i,:] for i in range(len(points_for_plotting)) if classe[i]==2])





	print(clsa.shape)
	print(clsb.shape)
	print(clsc.shape)


	plt.plot(clsa[:,0],clsa[:,1],"*")
	plt.plot(clsb[:,0],clsb[:,1],"*")
	plt.plot(clsc[:,0],clsc[:,1],"*")
	plt.title("RBF tanh")
	plt.show()


except Exception as e:
	print(e)






