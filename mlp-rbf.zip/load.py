import numpy as np

def load():

    df = np.array(np.loadtxt("seeds_dataset.txt"))

    for col in range(df.shape[1]-1):
        df[:,col] = df[:,col] / df[:,col].max()

    X = df[0:,0:df.shape[1]-1]

    aux = df[:,-1]
    Y = np.zeros((X.shape[0],3))
    for i in range(aux.shape[0]):
        if aux[i] == 1:
            Y[i,0] = 1
        elif aux[i] == 2:
            Y[i,1] = 1
        else:
            Y[i,2] = 1

    return X,Y

X,Y = load()

#print(X)
#print(Y)
